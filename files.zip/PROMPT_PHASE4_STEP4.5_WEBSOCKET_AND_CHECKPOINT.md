# 🤖 AUTOMATA — LLM SESSION PROMPT
## Phase 4 · Step 4.5 — WebSocket Real-Time Transaction Monitoring + Phase 4 Sync Checkpoint
### For: Dev 1 (Backend Developer)
### Prerequisite: Steps 4.1–4.4 must all be complete
### Note: This is the final backend session for Phase 4. After this, both devs sync.

---

## 🔴 READ THIS ENTIRE PROMPT BEFORE WRITING A SINGLE LINE OF CODE

This step adds a WebSocket server to the backend so the frontend can receive live
transaction status updates without polling. Read the full architecture section before
touching any file — you are modifying `index.ts`, which is the heart of the server.

---

## 📍 WHERE YOU ARE

### ✅ Already complete
- Phase 0–3 — Full backend foundation
- Step 4.1 — LI.FI real routes and swap transactions
- Step 4.2 — Circle CCTP V2 approve + burn transactions
- Step 4.3 — Real Aave V3 APY reads, 5-minute cache
- Step 4.4 — Real Aave V3 supply + Mento approve transactions

### 🔧 What you are doing in this session — Step 4.5
Two things in one session because they are tightly coupled:

1. **Add a WebSocket server** to `backend/src/index.ts`
2. **Create `backend/src/services/txMonitorService.ts`** — polls an RPC for transaction
   confirmation every 3 seconds and sends status updates through the WebSocket connection

### ⏳ After this session
Phase 4 is complete. Both devs run the Phase 4 sync checkpoint, then proceed to Phase 5
(end-to-end integration testing).

---

## 🗂️ FILES YOU ARE TOUCHING

```
backend/src/
├── index.ts                         ← 🎯 Add WebSocket server here
└── services/
    └── txMonitorService.ts          ← 🎯 CREATE this file
```

```
backend/src/services/
├── routeService.ts   ← ✅ Done — DO NOT TOUCH
├── swapService.ts    ← ✅ Done — DO NOT TOUCH
├── bridgeService.ts  ← ✅ Done — DO NOT TOUCH
├── balanceService.ts ← ✅ Done — DO NOT TOUCH
├── yieldService.ts   ← ✅ Done — DO NOT TOUCH
├── stakeService.ts   ← ✅ Done — DO NOT TOUCH
├── transferService.ts← ✅ Done — DO NOT TOUCH
├── feeService.ts     ← Leave as stub
└── resolverService.ts← Leave as stub
```

---

## 🔑 STEP 0 — VERIFY YOUR ENVIRONMENT

```bash
npm run dev
curl http://localhost:3001/health   # must return {"status":"ok"}
npx tsc --noEmit                    # must return zero errors
```

Quick regression — confirm all 4 prior steps still work:
```bash
# Test yield (4.3)
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"What yield can I get on Base?","walletAddress":"0x0000000000000000000000000000000000000001","geminiApiKey":"YOUR_KEY","sessionId":"verify-pre-45-a"}'

# Test stake (4.4)
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Deposit 5 USDC into Aave on Base","walletAddress":"0x0000000000000000000000000000000000000001","geminiApiKey":"YOUR_KEY","sessionId":"verify-pre-45-b"}'
```

Both must return real data. If either is broken, fix it before continuing.

---

## 🧠 STEP 1 — UNDERSTAND THE WEBSOCKET ARCHITECTURE

Before writing code, understand exactly how the WebSocket flow works end-to-end.

### The full flow after a user signs a transaction:

```
[User signs tx in Privy]
         ↓
[Frontend gets txHash back from Privy]
         ↓
[Frontend opens WebSocket connection to ws://localhost:3001]
         ↓
[Frontend sends: { type: "monitor", txHash: "0x...", chainId: "base" }]
         ↓
[Backend starts polling the chain RPC every 3 seconds]
         ↓
[Backend sends status updates through WebSocket:]
  { type: "status", txHash, status: "pending", confirmations: 0 }
  { type: "status", txHash, status: "pending", confirmations: 1 }
  { type: "status", txHash, status: "confirmed", confirmations: 2 }
         ↓
[Frontend StatusPanel updates in real time]
         ↓
[Backend stops polling after confirmed or failed]
```

### WebSocket vs HTTP polling — why WebSocket?

Without WebSocket, the frontend would have to keep sending HTTP requests to check
if a transaction confirmed. With WebSocket, the backend pushes updates as they happen.
The connection is persistent and lightweight. The frontend just listens.

### The WebSocket message protocol

You are defining a simple message format. Both sides must agree on it:

**Frontend → Backend (client sends):**
```json
{
  "type": "monitor",
  "txHash": "0xabc123...",
  "chainId": "base"
}
```

**Backend → Frontend (server sends):**
```json
{
  "type": "status",
  "txHash": "0xabc123...",
  "status": "pending",
  "confirmations": 1,
  "chainId": "base"
}
```
```json
{
  "type": "status",
  "txHash": "0xabc123...",
  "status": "confirmed",
  "confirmations": 2,
  "chainId": "base",
  "blockNumber": 12345678
}
```
```json
{
  "type": "status",
  "txHash": "0xabc123...",
  "status": "failed",
  "chainId": "base",
  "error": "Transaction reverted"
}
```

---

## 🛠️ STEP 2 — CONFIRM `ws` PACKAGE IS INSTALLED

```bash
cat package.json | grep '"ws"'
```

If it's there, it's installed. If not:
```bash
npm install ws
npm install -D @types/ws
```

Also confirm viem is available for transaction receipt reading (it should be):
```bash
cat package.json | grep viem
```

---

## 🛠️ STEP 3 — CREATE txMonitorService.ts

Create `backend/src/services/txMonitorService.ts`:

```typescript
// backend/src/services/txMonitorService.ts
// Polls a chain RPC for transaction status and sends updates via WebSocket.

import { createPublicClient, http } from 'viem';
import { base, baseSepolia, celo, celoAlfajores, mainnet, sepolia } from 'viem/chains';
import type { WebSocket } from 'ws';

// ─── Chain → viem chain object mapping ───────────────────────────

function getChain(chainId: string) {
  const isTestnet = process.env.NODE_ENV !== 'production';
  switch (chainId) {
    case 'base':     return isTestnet ? baseSepolia : base;
    case 'celo':     return isTestnet ? celoAlfajores : celo;
    case 'ethereum': return isTestnet ? sepolia : mainnet;
    default:         return isTestnet ? baseSepolia : base;
  }
}

function getRpcUrl(chainId: string): string {
  switch (chainId) {
    case 'base':     return process.env.BASE_RPC_URL ?? 'https://sepolia.base.org';
    case 'celo':     return process.env.CELO_RPC_URL ?? 'https://alfajores-forno.celo-testnet.org';
    case 'ethereum': return process.env.ETH_RPC_URL  ?? 'https://rpc.sepolia.org';
    default:         return process.env.BASE_RPC_URL ?? 'https://sepolia.base.org';
  }
}

// ─── Helper: send a message through the WebSocket ─────────────────

function sendStatus(ws: WebSocket, payload: object): void {
  try {
    if (ws.readyState === 1) { // 1 = OPEN
      ws.send(JSON.stringify(payload));
    }
  } catch (err) {
    // WebSocket may have closed between checks — safe to ignore
  }
}

// ─── Main polling function ────────────────────────────────────────

export async function pollTransactionStatus(
  ws: WebSocket,
  txHash: string,
  chainId: string
): Promise<void> {

  const chain = getChain(chainId);
  const rpcUrl = getRpcUrl(chainId);

  const client = createPublicClient({
    chain,
    transport: http(rpcUrl),
  });

  const MAX_POLLS = 60;           // maximum 60 polls = 3 minutes at 3s intervals
  const POLL_INTERVAL_MS = 3000;  // poll every 3 seconds
  const CONFIRMATIONS_REQUIRED = 2; // consider confirmed after 2 block confirmations

  let pollCount = 0;

  // Send initial "pending" status immediately
  sendStatus(ws, {
    type: 'status',
    txHash,
    chainId,
    status: 'pending',
    confirmations: 0,
  });

  while (pollCount < MAX_POLLS) {
    await new Promise(resolve => setTimeout(resolve, POLL_INTERVAL_MS));
    pollCount++;

    try {
      // Check if we have a receipt (null = not yet mined)
      const receipt = await client.getTransactionReceipt({
        hash: txHash as `0x${string}`,
      });

      if (!receipt) {
        // Not yet mined — send pending update
        sendStatus(ws, {
          type: 'status',
          txHash,
          chainId,
          status: 'pending',
          confirmations: 0,
          pollCount,
        });
        continue;
      }

      // Receipt exists — check if it succeeded or reverted
      if (receipt.status === 'reverted') {
        sendStatus(ws, {
          type: 'status',
          txHash,
          chainId,
          status: 'failed',
          error: 'Transaction reverted on chain.',
        });
        break; // stop polling
      }

      // Transaction succeeded — get current block to count confirmations
      const currentBlock = await client.getBlockNumber();
      const confirmations = Number(currentBlock) - Number(receipt.blockNumber);

      if (confirmations >= CONFIRMATIONS_REQUIRED) {
        // Fully confirmed
        sendStatus(ws, {
          type: 'status',
          txHash,
          chainId,
          status: 'confirmed',
          confirmations,
          blockNumber: Number(receipt.blockNumber),
        });
        break; // stop polling — we're done
      } else {
        // In a block but not yet enough confirmations
        sendStatus(ws, {
          type: 'status',
          txHash,
          chainId,
          status: 'pending',
          confirmations,
          blockNumber: Number(receipt.blockNumber),
        });
      }

    } catch (err: any) {
      // RPC error — log but keep polling (transient network issues are common)
      console.error(`[txMonitor] Poll error for ${txHash} on ${chainId}:`, err.message);
      // Don't break the loop on transient errors — try again next poll
    }
  }

  // If we reach here without breaking, we hit the max poll limit
  if (pollCount >= MAX_POLLS) {
    sendStatus(ws, {
      type: 'status',
      txHash,
      chainId,
      status: 'failed',
      error: 'Transaction monitoring timed out after 3 minutes. Check the explorer manually.',
    });
  }
}
```

---

## 🛠️ STEP 4 — UPDATE index.ts TO ADD THE WEBSOCKET SERVER

Read the current index.ts first:
```bash
cat backend/src/index.ts
```

You need to:
1. Change from `app.listen()` to `server.listen()` (WebSocket needs a raw HTTP server)
2. Attach the WebSocket server to the HTTP server
3. Handle incoming WebSocket messages and start polling

Here is the full updated `index.ts`. Study the diff carefully — you are not rewriting
the file from scratch. Preserve everything that was already there (session handling,
`/api/chat` route, cors config, etc.) and add the WebSocket pieces:

```typescript
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer } from 'http';           // ADD THIS
import { WebSocketServer } from 'ws';          // ADD THIS
import { pollTransactionStatus } from './services/txMonitorService'; // ADD THIS

dotenv.config();

const app = express();
const PORT = process.env.PORT ?? 3001;

app.use(cors({ origin: process.env.CORS_ORIGIN ?? 'http://localhost:3000' }));
app.use(express.json({ limit: '10mb' }));

// ── Health check ──────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── /api/chat route ────────────────────────────────────────────────
// (keep everything that was already here — sessions, runAgent, etc.)
// ... [your existing /api/chat code stays exactly as-is] ...

// ── HTTP server (replaces app.listen) ─────────────────────────────
// WebSocket requires an underlying HTTP server — we create it explicitly.
const server = createServer(app);

// ── WebSocket server ───────────────────────────────────────────────
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  console.log('[WebSocket] Client connected');

  ws.on('message', async (data) => {
    try {
      const message = JSON.parse(data.toString());

      if (message.type === 'monitor' && message.txHash && message.chainId) {
        console.log(`[WebSocket] Starting monitor: ${message.txHash} on ${message.chainId}`);
        // Start polling in the background — do not await here
        // (we don't want to block the WebSocket message handler)
        pollTransactionStatus(ws, message.txHash, message.chainId).catch(err => {
          console.error('[WebSocket] pollTransactionStatus error:', err);
        });
      } else {
        ws.send(JSON.stringify({ type: 'error', message: 'Unknown message type or missing fields' }));
      }
    } catch (err) {
      ws.send(JSON.stringify({ type: 'error', message: 'Invalid JSON message' }));
    }
  });

  ws.on('close', () => {
    console.log('[WebSocket] Client disconnected');
  });

  ws.on('error', (err) => {
    console.error('[WebSocket] Error:', err);
  });

  // Send a welcome message so the frontend knows the connection is live
  ws.send(JSON.stringify({ type: 'connected', message: 'Automata WebSocket ready' }));
});

// ── Start listening ───────────────────────────────────────────────
// Use server.listen() instead of app.listen() — HTTP + WebSocket share the same port
server.listen(PORT, () => {
  console.log(`Automata backend running on port ${PORT} (HTTP + WebSocket)`);
});
```

**Critical:** Do not replace the existing `/api/chat` route handler and session logic.
Only add the `createServer`, `WebSocketServer`, and `wss.on('connection')` blocks.
Preserve everything else.

---

## 🛠️ STEP 5 — TYPESCRIPT CHECK

```bash
npx tsc --noEmit
```

Common errors:
- `WebSocketServer` may need to be imported as `import { WebSocketServer } from 'ws'` — confirm your `ws` package version supports named exports
- `celoAlfajores` may not be exported from your version of `viem/chains` — use `celo` with the testnet RPC URL override instead
- `createServer` must be imported from `'http'` (Node built-in), not from express

---

## 🛠️ STEP 6 — TEST THE WEBSOCKET SERVER

### Test 1 — WebSocket connection test using wscat or websocat

Install a WebSocket CLI tool if you don't have one:
```bash
# Option A — wscat (npm)
npm install -g wscat
wscat -c ws://localhost:3001

# Option B — websocat (binary)
# Download from: https://github.com/vi/websocat/releases
```

After connecting, you should immediately receive:
```json
{"type":"connected","message":"Automata WebSocket ready"}
```

### Test 2 — Monitor a real testnet transaction hash

Get any real Base Sepolia transaction hash from https://sepolia.basescan.org
(use any confirmed transaction — you don't need one from Automata).

Send the monitor message:
```json
{"type":"monitor","txHash":"0xYOUR_REAL_TX_HASH","chainId":"base"}
```

**Expected:** Within a few seconds you should receive:
```json
{"type":"status","txHash":"0xYOUR_REAL_TX_HASH","chainId":"base","status":"confirmed","confirmations":12,"blockNumber":12345678}
```

(The confirmations number will be high because the transaction is already confirmed.)

### Test 3 — HTTP health check still works (regression)
In a new terminal while the WebSocket test is running:
```bash
curl http://localhost:3001/health
```
Expected: `{"status":"ok","timestamp":"..."}` — HTTP and WebSocket must coexist on the same port.

### Test 4 — /api/chat still works (regression)
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Hello","walletAddress":"0x0000000000000000000000000000000000000001","geminiApiKey":"YOUR_KEY","sessionId":"test-ws-regress"}'
```
Expected: agent responds normally. HTTP routes must still work after the WebSocket addition.

### Test 5 — Invalid message handling
In wscat, send a broken message:
```json
{"type":"unknown","data":"garbage"}
```
Expected: server sends back `{"type":"error","message":"Unknown message type or missing fields"}` and does not crash.

---

## 🛠️ STEP 7 — TYPESCRIPT CHECK (FINAL)

```bash
npx tsc --noEmit
```
Zero errors.

---

## 🛠️ STEP 8 — COMMIT

```bash
git add backend/src/services/txMonitorService.ts
git add backend/src/index.ts
git commit -m "feat: WebSocket server + real-time tx monitor polling — Phase 4 Step 4.5"
git push
```

---

# ── PHASE 4 SYNC CHECKPOINT ──────────────────────────────────────

After Step 4.5 is committed and passing all tests, run this full checklist.
Do not mark Phase 4 complete until every item is checked.

## Backend verification (Dev 1)

```bash
cd backend && npm run dev
```

- [ ] `curl http://localhost:3001/health` returns `{"status":"ok"}`
- [ ] `npx tsc --noEmit` returns zero errors
- [ ] POST /api/chat with "swap 10 USDC from Base to cUSD" returns real LI.FI route (4.1)
- [ ] POST /api/chat with "bridge 5 USDC from Base to Celo" returns approve + burn txs (4.2)
- [ ] POST /api/chat with "where can I earn yield" returns real Aave APY (4.3)
- [ ] POST /api/chat with "deposit 10 USDC into Aave on Base" returns approve + supply txs (4.4)
- [ ] WebSocket connection at ws://localhost:3001 receives `{"type":"connected",...}` (4.5)
- [ ] Monitoring a real testnet txHash returns a confirmed status (4.5)
- [ ] All 5 steps' curl tests pass without any errors or timeouts
- [ ] Zero console errors during any of the above tests

## Frontend coordination (Dev 1 to notify Dev 2)

The WebSocket server is now running. Dev 2 needs to wire the frontend StatusPanel
to connect to this WebSocket and listen for status updates after a transaction is signed.

Share these details with Dev 2:
- WebSocket URL: `ws://localhost:3001` (local) / `wss://your-deployed-url` (production)
- Connect message: `{ type: "monitor", txHash: "0x...", chainId: "base" }`
- Status updates arrive as: `{ type: "status", status: "pending" | "confirmed" | "failed", ... }`
- Connection confirmation: `{ type: "connected", message: "Automata WebSocket ready" }`

---

## 🛠️ UPDATE PROGRESS.md (Phase 4 complete)

```
## 📍 CURRENT POSITION

PHASE:   5 — INTEGRATION & END-TO-END TESTING
STEP:    5.1 — USDC transfer end-to-end test
STATUS:  IN PROGRESS

Dev 1: Phase 4 complete. All 5 steps done and verified.
LI.FI routes live. CCTP V2 bridge real. Aave yield real.
Aave supply calldata real. WebSocket tx monitor running.
Dev 2: Wire frontend StatusPanel to ws://localhost:3001 for real-time updates.

Next: Phase 5 — both devs run end-to-end tests on testnet together.
```

Mark all Phase 4 steps complete:
```
- [x] Step 4.1: routeService.ts and swapService.ts use real @lifi/sdk
- [x] Step 4.2: bridgeService.ts builds real Circle CCTP V2 approve + burn txs
- [x] Step 4.3: yieldService.ts reads real Aave V3 APY, Mento estimated
- [x] Step 4.4: stakeService.ts builds real Aave V3 approve + supply calldata
- [x] Step 4.5: WebSocket server + txMonitorService — real-time tx monitoring
```

```bash
git add PROGRESS.md
git commit -m "progress: Phase 4 complete — all real service implementations done"
git push
```

---

## ✅ DONE WHEN — CHECKLIST

- [ ] `txMonitorService.ts` created and exports `pollTransactionStatus`
- [ ] `index.ts` uses `createServer(app)` and `WebSocketServer` — HTTP and WS share port 3001
- [ ] WebSocket connection at ws://localhost:3001 works and sends the connected message
- [ ] Monitoring a real testnet txHash receives a confirmed status message
- [ ] HTTP routes (`/health`, `/api/chat`) still work with the new server setup
- [ ] Invalid WebSocket message returns error, does not crash server
- [ ] `npx tsc --noEmit` returns zero errors
- [ ] All Phase 4 sync checkpoint items above are checked
- [ ] PROGRESS.md updated, Phase 4 marked complete, positioned at Phase 5
- [ ] Dev 2 notified of WebSocket protocol details

---

## ⚠️ DO NOT DO THESE THINGS

1. **Do not replace `app.listen` with `server.listen` before adding the HTTP server** — if you skip `const server = createServer(app)`, the app will break.
2. **Do not `await` `pollTransactionStatus` inside the WebSocket message handler** — this would block the handler thread. Always call it without await and handle errors with `.catch()`.
3. **Do not set POLL_INTERVAL_MS below 2000** — polling faster than every 2 seconds risks rate-limiting by the RPC provider.
4. **Do not remove session logic from index.ts** — you are adding WebSocket to the existing file, not replacing it.
5. **Do not implement WebSocket on a different port** — HTTP and WebSocket must share port 3001 so there is only one origin to configure in CORS.

---

## 🆘 COMMON ERRORS AND FIXES

| Error | Cause | Fix |
|---|---|---|
| `Cannot find module 'ws'` | Package not installed | `npm install ws && npm install -D @types/ws` |
| `WebSocketServer is not a constructor` | Old `ws` version uses default export | `import WebSocket from 'ws'; const wss = new WebSocket.Server({ server })` |
| `celoAlfajores not found` | viem version doesn't export it | Use `import { celo } from 'viem/chains'` and override with env RPC URL |
| `EADDRINUSE :3001` | Old `app.listen` is still in the file | Remove `app.listen` — replace with `server.listen` |
| WebSocket connects but no messages | `pollTransactionStatus` throwing silently | Add `console.error` inside the `.catch()` and check terminal output |
| `getTransactionReceipt` returns null indefinitely | txHash doesn't exist on that chain/testnet | Confirm the txHash is from the correct network |

---

## 📚 REFERENCE LINKS

| Resource | URL |
|---|---|
| `ws` npm package | https://www.npmjs.com/package/ws |
| viem getTransactionReceipt | https://viem.sh/docs/actions/public/getTransactionReceipt |
| viem getBlockNumber | https://viem.sh/docs/actions/public/getBlockNumber |
| Base Sepolia Explorer | https://sepolia.basescan.org |
| Celo Alfajores Explorer | https://alfajores.celoscan.io |
| PROGRESS.md | /Automata-V2/PROGRESS.md |

---

*This session: Step 4.5 + Phase 4 checkpoint. Phase 4 is complete.*
*Next: Phase 5 — both devs together for end-to-end testnet integration testing.*
