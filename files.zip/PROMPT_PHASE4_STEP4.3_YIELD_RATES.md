# 🤖 AUTOMATA — LLM SESSION PROMPT
## Phase 4 · Step 4.3 — Replace Yield Stub with Real Aave V3 + Mento On-Chain Reads
### For: Dev 1 (Backend Developer)
### Prerequisite: Steps 4.1 and 4.2 must be complete

---

## 🔴 READ THIS ENTIRE PROMPT BEFORE WRITING A SINGLE LINE OF CODE

---

## 📍 WHERE YOU ARE

### ✅ Already complete
- Phase 0–3 — Everything up to and including the full backend logic layer
- Step 4.1 — `routeService.ts` uses real `@lifi/sdk`
- Step 4.2 — `bridgeService.ts` builds real CCTP approve + burn transactions

### 🔧 What you are doing in this session — Step 4.3
Replace `backend/src/services/yieldService.ts` with real on-chain reads from:
- **Aave V3** on Base and Ethereum — read current USDC supply APY from the Pool contract
- **Mento** on Celo — read exchange rates and yield data from Mento's registry

Return the top 3 yield options sorted by APY, descending. Cache results for 5 minutes
to avoid hammering RPC endpoints on every agent call.

### ⏳ After this session
- Step 4.4 — Real Aave + Mento stake/deposit transactions
- Step 4.5 — WebSocket real-time transaction monitoring

---

## 🗂️ FILES YOU ARE AND ARE NOT TOUCHING

```
backend/src/services/
├── routeService.ts   ← ✅ Done 4.1 — DO NOT TOUCH
├── swapService.ts    ← ✅ Done 4.1 — DO NOT TOUCH
├── bridgeService.ts  ← ✅ Done 4.2 — DO NOT TOUCH
├── balanceService.ts ← Real already — DO NOT TOUCH
├── yieldService.ts   ← 🎯 YOU ARE REPLACING THIS TODAY
├── stakeService.ts   ← Leave for Step 4.4
├── transferService.ts← Real already — DO NOT TOUCH
├── feeService.ts     ← Leave as stub
└── resolverService.ts← Leave as stub
```

---

## 🔑 STEP 0 — VERIFY YOUR ENVIRONMENT

```bash
# From backend/ folder
npm run dev
curl http://localhost:3001/health        # must return {"status":"ok"}
npx tsc --noEmit                         # must return zero errors
```

Also confirm your testnet RPC URLs are in `.env`:
```bash
cat .env | grep RPC
```
You need `BASE_RPC_URL`, `CELO_RPC_URL`, and `ETH_RPC_URL` all set to testnet endpoints.

---

## 🧠 STEP 1 — UNDERSTAND WHAT YOU ARE READING FROM THE CHAIN

### Aave V3 — How to read the current USDC supply APY

Aave V3 exposes a contract called the `Pool` (formerly `LendingPool`). It has a function:

```solidity
function getReserveData(address asset)
  external view returns (ReserveData memory data);
```

Inside `ReserveData`, the field you want is `currentLiquidityRate`.
This is a ray-scaled number (1 ray = 1e27). To convert to a human-readable APY percentage:

```
APY = (1 + currentLiquidityRate / 1e27 / 365_days_in_seconds) ^ 365_days_in_seconds - 1
```

Or a simplified version that's accurate enough for display:
```
APY ≈ (currentLiquidityRate / 1e27) * 100
```

The simplified formula gives you a percentage like `3.42` (meaning 3.42% APY).

**Aave V3 Pool contract addresses (testnet):**
```
Aave V3 on Base Sepolia:     0x07eA79F68B2B3df564D0A34F8e19D9B1e339814b
Aave V3 on Ethereum Sepolia: 0x6Ae43d3271ff6888e7Fc43Fd7321a503ff738951
```

**Aave V3 Pool contract addresses (mainnet, for reference):**
```
Aave V3 on Base mainnet:     0xA238Dd80C259a72e81d7e4664a9801593F98d1c5
Aave V3 on Ethereum mainnet: 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2
```

Use testnet for Phase 4.

**USDC addresses (testnet):**
```
Base Sepolia:     0x036CbD53842c5426634e7929541eC2318f3dCF7e
Ethereum Sepolia: 0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238
```

### Mento on Celo — How to read yield rates

Mento is Celo's stability protocol. It does not have a simple APY like Aave.
Instead, Mento provides stablecoin exchange (swapping cUSD, cKES, cEUR).
For the purposes of this step, there are two options:

**Option A (recommended for Phase 4):** Hardcode a realistic Mento yield estimate
(e.g. 4.5% APY for cUSD) and label it clearly as an estimate. This is pragmatic —
Mento's "yield" comes from holding cUSD which appreciates relative to celo inflationary
pressure, and the exact rate is not easily queryable via a single contract read.

**Option B (advanced):** Read from Mento's reserve contract, but this requires
multi-contract reads and is out of scope for Phase 4.

**Use Option A** for this step. The code comment must clearly say:
`// TODO Phase 5: Replace with real Mento protocol read`

This is honest, doesn't block progress, and gives the user real Aave data plus
a reasonable Mento estimate.

---

## 🛠️ STEP 2 — READ THE CURRENT STUB

```bash
cat backend/src/services/yieldService.ts
```

Note the exported function name (must stay `getYieldRates`) and the parameter and return shape.

Also check toolExecutor:
```bash
cat backend/src/agent/toolExecutor.ts | grep -A 5 "yield"
```

The return shape your function produces must match what toolExecutor passes back to the agent.

---

## 🛠️ STEP 3 — WRITE THE NEW yieldService.ts

```typescript
// backend/src/services/yieldService.ts

import { createPublicClient, http, parseAbi } from 'viem';
import { baseSepolia, sepolia } from 'viem/chains';

// ─── In-memory cache ──────────────────────────────────────────────
// Cache yield data for 5 minutes to avoid hammering RPCs
type CacheEntry = { data: any; expiresAt: number };
const cache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

function getCached(key: string): any | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return null;
  }
  return entry.data;
}

function setCache(key: string, data: any): void {
  cache.set(key, { data, expiresAt: Date.now() + CACHE_TTL_MS });
}

// ─── Aave V3 Pool ABI (only the function we need) ─────────────────
const AAVE_POOL_ABI = parseAbi([
  'function getReserveData(address asset) view returns (' +
    'uint256 configuration, ' +
    'uint128 liquidityIndex, ' +
    'uint128 currentLiquidityRate, ' +
    'uint128 variableBorrowIndex, ' +
    'uint128 currentVariableBorrowRate, ' +
    'uint128 currentStableBorrowRate, ' +
    'uint40 lastUpdateTimestamp, ' +
    'uint16 id, ' +
    'address aTokenAddress, ' +
    'address stableDebtTokenAddress, ' +
    'address variableDebtTokenAddress, ' +
    'address interestRateStrategyAddress, ' +
    'uint128 accruedToTreasury, ' +
    'uint128 unbacked, ' +
    'uint128 isolationModeTotalDebt' +
  ')',
]);

// ─── Contract and token addresses (testnet) ───────────────────────
const AAVE_POOLS: Record<string, { poolAddress: `0x${string}`; usdcAddress: `0x${string}`; chain: any }> = {
  base: {
    poolAddress: '0x07eA79F68B2B3df564D0A34F8e19D9B1e339814b',
    usdcAddress: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
    chain: baseSepolia,
  },
  ethereum: {
    poolAddress: '0x6Ae43d3271ff6888e7Fc43Fd7321a503ff738951',
    usdcAddress: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
    chain: sepolia,
  },
};

// ─── Helper: convert Aave ray rate to APY percentage ──────────────
function rayToAPY(ray: bigint): number {
  // Simplified conversion: ray / 1e25 gives percentage
  // For display purposes this is accurate to ±0.1%
  const rateDecimal = Number(ray) / 1e27;
  return parseFloat((rateDecimal * 100).toFixed(2));
}

// ─── Read Aave APY for a single chain ────────────────────────────
async function getAaveAPY(chainKey: string): Promise<{ protocol: string; chain: string; token: string; apy: number; tvlNote: string } | null> {
  const cacheKey = `aave_${chainKey}`;
  const cached = getCached(cacheKey);
  if (cached) return cached;

  const config = AAVE_POOLS[chainKey];
  if (!config) return null;

  try {
    const client = createPublicClient({
      chain: config.chain,
      transport: http(
        chainKey === 'base'
          ? process.env.BASE_RPC_URL
          : process.env.ETH_RPC_URL
      ),
    });

    const reserveData = await client.readContract({
      address: config.poolAddress,
      abi: AAVE_POOL_ABI,
      functionName: 'getReserveData',
      args: [config.usdcAddress],
    }) as any;

    // currentLiquidityRate is the 3rd field in the tuple (index 2)
    const liquidityRate: bigint = reserveData[2];
    const apy = rayToAPY(liquidityRate);

    const result = {
      protocol: 'Aave V3',
      chain: chainKey,
      token: 'USDC',
      apy,
      tvlNote: 'Battle-tested. Largest DeFi lending protocol.',
    };

    setCache(cacheKey, result);
    return result;

  } catch (err) {
    console.error(`[yieldService] Failed to read Aave APY for ${chainKey}:`, err);
    return null;
  }
}

// ─── Main exported function ───────────────────────────────────────
export async function getYieldRates(params: {
  chain?: string;
  token?: string;
}): Promise<any> {

  const { chain, token } = params;
  const results: any[] = [];

  // If a specific chain is requested, only fetch that chain
  const chainsToCheck = chain && chain !== 'all'
    ? [chain]
    : ['base', 'ethereum', 'celo'];

  for (const c of chainsToCheck) {
    if (c === 'base' || c === 'ethereum') {
      const aaveData = await getAaveAPY(c);
      if (aaveData) results.push(aaveData);
    }

    if (c === 'celo') {
      // TODO Phase 5: Replace with real Mento protocol read
      // Mento cUSD yield is estimated based on stability reserve mechanics.
      // Actual returns vary based on Celo network conditions.
      results.push({
        protocol: 'Mento',
        chain: 'celo',
        token: 'cUSD',
        apy: 4.50,
        tvlNote: 'Estimated. Celo\'s native stablecoin protocol.',
        isEstimate: true,
      });
    }
  }

  if (results.length === 0) {
    return {
      error: true,
      message: `No yield rates available for ${chain ?? 'any chain'} and ${token ?? 'any token'} right now. Try again in a moment.`,
    };
  }

  // Sort by APY descending — best rate first
  results.sort((a, b) => b.apy - a.apy);

  return {
    rates: results,
    topRecommendation: results[0],
    note: results.some(r => r.isEstimate)
      ? 'Mento rate is estimated. Aave rates are live from the blockchain.'
      : 'All rates are live from the blockchain.',
    cachedUntil: new Date(Date.now() + CACHE_TTL_MS).toISOString(),
  };
}
```

---

## 🛠️ STEP 4 — HANDLE THE AAVE ABI RETURN TUPLE

Aave's `getReserveData` returns a large struct. The way viem returns it depends on
whether you use a named tuple or a positional tuple in the ABI.

The ABI definition above uses a positional struct. If your viem version returns
the data as an array (positional), `reserveData[2]` is `currentLiquidityRate`.
If it returns a named object, use `reserveData.currentLiquidityRate`.

**Add a safe accessor to handle both:**
```typescript
const liquidityRate: bigint =
  (reserveData as any).currentLiquidityRate ??
  (reserveData as any)[2] ??
  BigInt(0);
```

If `liquidityRate` comes back as `0n`, the RPC call likely succeeded but the
testnet pool has no active liquidity. This is normal on testnets — the APY
will display as 0%. That is correct behaviour and is not a bug.

---

## 🛠️ STEP 5 — TYPESCRIPT CHECK

```bash
npx tsc --noEmit
```

Common type errors to fix:
- `viem/chains` might not export `baseSepolia` by name in older versions — try `import { base } from 'viem/chains'` and use the mainnet chain object with the testnet RPC URL override via `http(process.env.BASE_RPC_URL)`
- `parseAbi` may produce a type that viem's `readContract` doesn't accept directly — cast `abi: AAVE_POOL_ABI as any` if needed
- The `reserveData` return type is complex — use `as any` on the cast temporarily

---

## 🛠️ STEP 6 — TEST WITH CURL

```bash
npm run dev
```

### Test 1 — Ask for yield rates across all chains
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Where can I earn the best yield on my USDC right now?",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-yield-001"
  }'
```

**Expected:** Agent calls `get_yield_rates`, gets back 3 results (Aave Base,
Aave Ethereum, Mento Celo), responds with a plain-English recommendation showing
which protocol has the best APY.

### Test 2 — Ask for yield on a specific chain
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What yield can I get on Celo?",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-yield-002"
  }'
```

**Expected:** Agent returns only the Mento Celo result (4.50% estimated).

### Test 3 — Cache verification (run Test 1 twice within 5 minutes)
Run Test 1 again immediately. Check backend logs — the second call should NOT
show an RPC request being made (the cache should serve the result). The response
time should be noticeably faster (milliseconds vs. seconds).

### Test 4 — Regression: bridge and swap still work
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Move 5 USDC from Base to Celo",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-yield-004"
  }'
```
**Expected:** CCTP bridge still works. Not broken.

---

## 🛠️ STEP 7 — TYPESCRIPT CHECK (FINAL)

```bash
npx tsc --noEmit
```
Zero errors.

---

## 🛠️ STEP 8 — COMMIT

```bash
git add backend/src/services/yieldService.ts
git commit -m "feat: real Aave V3 yield rates + Mento estimate — Phase 4 Step 4.3"
git push
```

---

## 🛠️ STEP 9 — UPDATE PROGRESS.md

```
## 📍 CURRENT POSITION

PHASE:   4 — REAL SERVICE IMPLEMENTATIONS
STEP:    4.4 — Real Aave + Mento stake/deposit transactions
STATUS:  IN PROGRESS

Dev 1: Step 4.3 complete. yieldService.ts reads real Aave V3 currentLiquidityRate
via viem. Mento returns 4.5% estimate with TODO comment for Phase 5.
5-minute in-memory cache confirmed working. Sorted by APY descending.

Next: Replace stakeService.ts stub with real Aave V3 supply calldata.
```

Mark complete:
```
- [x] Step 4.3: yieldService.ts reads real Aave V3 APY. Mento estimated.
      Cache working. Rates sorted descending. Regression tests passed.
```

```bash
git add PROGRESS.md
git commit -m "progress: Phase 4 Step 4.3 complete — real yield rates integrated"
git push
```

---

## ✅ DONE WHEN — CHECKLIST

- [ ] `npx tsc --noEmit` returns zero errors
- [ ] Test 1: Agent returns real Aave APY numbers (not 0%, not hardcoded "5%")
- [ ] Test 1: Mento rate shows 4.50% with note that it is estimated
- [ ] Test 1: Results sorted by APY — highest rate is listed first
- [ ] Test 2: Chain-specific query returns only Celo results
- [ ] Test 3: Second call within 5 minutes is served from cache (faster response, no RPC log)
- [ ] Test 4: Bridge and swap (steps 4.1 and 4.2) still work — no regression
- [ ] PROGRESS.md updated and committed

---

## ⚠️ DO NOT DO THESE THINGS

1. **Do not rename `getYieldRates`** — toolExecutor depends on this exact export name.
2. **Do not remove the Mento stub** — replacing it with real Mento reads is a Phase 5 task. The estimate is intentional and honest (labelled `isEstimate: true`).
3. **Do not set cache TTL lower than 5 minutes** — Aave rates change slowly and hammering RPC endpoints causes failures under load.
4. **Do not throw errors for zero APY** — on testnets, Aave may return 0% because there's no active liquidity. Return 0% and let the agent tell the user.
5. **Do not touch any adapter files** — `adapters/evm.ts` already has viem clients. You are building your own within the service to keep concerns separated.

---

## 🆘 COMMON ERRORS AND FIXES

| Error | Cause | Fix |
|---|---|---|
| `baseSepolia not exported from viem/chains` | Older viem version | Use `import { base } from 'viem/chains'` and pass `transport: http(process.env.BASE_RPC_URL)` which overrides the RPC to testnet |
| `getReserveData reverted` | Pool address wrong for the chain or contract not deployed on testnet | Double-check the Aave V3 testnet address for that chain at https://docs.aave.com/developers/deployed-contracts |
| `currentLiquidityRate` is `0n` | Testnet pool has no active liquidity | Normal behaviour on testnets. APY = 0% is correct. |
| `Cannot read property '2' of undefined` | `readContract` returned null | Wrap in try/catch and return null — the outer function handles null returns |
| Agent doesn't call `get_yield_rates` | Gemini didn't understand the intent | Try rephrasing the test message to "what yield can I earn" or "best APY for USDC" |

---

## 📚 REFERENCE LINKS

| Resource | URL |
|---|---|
| Aave V3 Deployed Contracts | https://docs.aave.com/developers/deployed-contracts/v3-testnet-addresses |
| Aave V3 Pool Interface | https://docs.aave.com/developers/core-contracts/pool |
| viem readContract Docs | https://viem.sh/docs/contract/readContract |
| Mento Protocol Docs | https://docs.mento.org |
| PROGRESS.md | /Automata-V2/PROGRESS.md |

---

*This session: Step 4.3 only. Next session: Step 4.4 — Real Aave/Mento stake transactions.*
