# 🤖 AUTOMATA — LLM SESSION PROMPT
## Phase 4 · Step 4.4 — Replace Stake Stub with Real Aave V3 + Mento Deposit Calldata
### For: Dev 1 (Backend Developer)
### Prerequisite: Step 4.3 must be complete — yieldService.ts reads real Aave APY

---

## 🔴 READ THIS ENTIRE PROMPT BEFORE WRITING A SINGLE LINE OF CODE

---

## 📍 WHERE YOU ARE

### ✅ Already complete
- Phase 0–3 — Full backend foundation
- Step 4.1 — LI.FI real routes and swap transactions
- Step 4.2 — Circle CCTP V2 approve + burn transactions
- Step 4.3 — Real Aave V3 APY reads + Mento estimate, 5-minute cache

### 🔧 What you are doing in this session — Step 4.4
Replace `backend/src/services/stakeService.ts` with real protocol ABI calls that
build genuine unsigned deposit transactions for:

- **Aave V3** on Base and Ethereum — call `supply()` on the Aave Pool contract
- **Mento** on Celo — call the Mento exchange to swap USDC → cUSD (Mento's "yield"
  comes from holding cUSD, so depositing into Mento means swapping to cUSD)

Both follow the same two-transaction pattern as CCTP: an `approve` first,
then the actual deposit/swap.

The function `buildStakeTx` must remain exported with the same name.

### ⏳ After this session
- Step 4.5 — WebSocket real-time transaction monitoring (the final backend step)

---

## 🗂️ FILES YOU ARE AND ARE NOT TOUCHING

```
backend/src/services/
├── routeService.ts   ← ✅ Done — DO NOT TOUCH
├── swapService.ts    ← ✅ Done — DO NOT TOUCH
├── bridgeService.ts  ← ✅ Done — DO NOT TOUCH
├── balanceService.ts ← ✅ Real — DO NOT TOUCH
├── yieldService.ts   ← ✅ Done — DO NOT TOUCH
├── stakeService.ts   ← 🎯 YOU ARE REPLACING THIS TODAY
├── transferService.ts← ✅ Real — DO NOT TOUCH
├── feeService.ts     ← Leave as stub
└── resolverService.ts← Leave as stub
```

---

## 🔑 STEP 0 — VERIFY YOUR ENVIRONMENT

```bash
npm run dev
curl http://localhost:3001/health   # must return {"status":"ok"}
npx tsc --noEmit                    # zero errors
```

Quick regression — confirm Steps 4.1–4.3 still work:
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Where can I earn yield on USDC?","walletAddress":"0x0000000000000000000000000000000000000001","geminiApiKey":"YOUR_KEY","sessionId":"verify-pre-44"}'
```
Expected: agent returns yield rates with real Aave APY numbers. If broken — fix before continuing.

---

## 🧠 STEP 1 — UNDERSTAND WHAT YOU ARE BUILDING

### Aave V3 supply — the deposit flow

Depositing USDC into Aave V3 requires two transactions in sequence:

**Transaction 1 — approve:**
The user approves the Aave Pool contract to spend their USDC.
This is a standard ERC-20 `approve(spender, amount)` on the USDC contract.

**Transaction 2 — supply:**
The user calls `supply()` on the Aave V3 Pool contract:
```solidity
function supply(
    address asset,        // USDC contract address on this chain
    uint256 amount,       // USDC amount in smallest unit (6 decimals)
    address onBehalfOf,   // wallet address to credit with aTokens
    uint16 referralCode   // always 0 for Automata (no referral program)
) external;
```

After this call, the user receives `aUSDC` tokens in their wallet.
These automatically accrue interest at the Aave APY rate.

**Aave V3 Pool addresses (testnet):**
```
Base Sepolia:     0x07eA79F68B2B3df564D0A34F8e19D9B1e339814b
Ethereum Sepolia: 0x6Ae43d3271ff6888e7Fc43Fd7321a503ff738951
```

**USDC addresses (testnet):**
```
Base Sepolia:     0x036CbD53842c5426634e7929541eC2318f3dCF7e
Ethereum Sepolia: 0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238
```

### Mento — the Celo swap flow

Mento is Celo's stability protocol. To "stake" via Mento means swapping USDC → cUSD.
The user holds cUSD, which is a yield-bearing stablecoin on Celo.

Mento exchange contract on Celo Alfajores (testnet):
```
Mento Broker: 0x626F97a2B0A9C50919E26f05b7Fce0aBce18bf54
```

Mento uses a different pattern — you call `swapIn()` on the Broker contract:
```solidity
function swapIn(
    address exchangeProvider,
    bytes32 exchangeId,
    address tokenIn,       // USDC address on Celo
    address tokenOut,      // cUSD address on Celo
    uint256 amountIn,      // amount of USDC to swap (6 decimals)
    uint256 amountOutMin   // minimum cUSD to receive (18 decimals)
) external returns (uint256 amountOut);
```

However, the Mento Broker address and exchange IDs change between testnet and mainnet,
and the exact exchange ID for USDC→cUSD requires a runtime lookup.

**For Phase 4, use a pragmatic approach for Mento:**
Build the approve transaction (approve Mento Broker to spend USDC), and for the
swap transaction, build a stub with a clear TODO comment indicating the exchange ID
needs to be fetched at runtime. This gives the user a real approve transaction to
sign and a placeholder for the swap. The swap will be completed in Phase 5.

**USDC on Celo Alfajores:** `0x2F25deB3848C207fc8E0c34035B3Ba7fC157602B`
**cUSD on Celo Alfajores:** `0x874069Fa1Eb16D44d622F2e0Ca25eeA172369bC1`

---

## 🛠️ STEP 2 — READ THE CURRENT STUB

```bash
cat backend/src/services/stakeService.ts
```

Note the function signature and return shape. It must remain identical.
The toolExecutor expects `buildStakeTx` and a specific return structure.

```bash
cat backend/src/agent/toolExecutor.ts | grep -A 10 "stake"
```

Understand how the toolExecutor handles the stake result before you change anything.

---

## 🛠️ STEP 3 — WRITE THE NEW stakeService.ts

```typescript
// backend/src/services/stakeService.ts

import { encodeFunctionData, parseUnits } from 'viem';

// ─── Contract addresses (testnet) ────────────────────────────────

const AAVE_POOL: Record<string, `0x${string}`> = {
  base:     '0x07eA79F68B2B3df564D0A34F8e19D9B1e339814b',
  ethereum: '0x6Ae43d3271ff6888e7Fc43Fd7321a503ff738951',
};

const USDC_ADDRESS: Record<string, `0x${string}`> = {
  base:     '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
  ethereum: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
  celo:     '0x2F25deB3848C207fc8E0c34035B3Ba7fC157602B',
};

const CUSD_ADDRESS: `0x${string}` = '0x874069Fa1Eb16D44d622F2e0Ca25eeA172369bC1'; // Celo Alfajores

const MENTO_BROKER: `0x${string}` = '0x626F97a2B0A9C50919E26f05b7Fce0aBce18bf54'; // Celo Alfajores

// ─── ABI Fragments ───────────────────────────────────────────────

const ERC20_APPROVE_ABI = [
  {
    name: 'approve',
    type: 'function',
    inputs: [
      { name: 'spender', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ type: 'bool' }],
  },
] as const;

const AAVE_SUPPLY_ABI = [
  {
    name: 'supply',
    type: 'function',
    inputs: [
      { name: 'asset', type: 'address' },
      { name: 'amount', type: 'uint256' },
      { name: 'onBehalfOf', type: 'address' },
      { name: 'referralCode', type: 'uint16' },
    ],
    outputs: [],
  },
] as const;

// ─── Aave V3 supply builder ───────────────────────────────────────

function buildAaveSupply(params: {
  chain: string;
  amount: string;
  walletAddress: string;
}): { unsignedTxs: any[]; summary: any } | { error: true; message: string } {

  const { chain, amount, walletAddress } = params;

  if (!AAVE_POOL[chain]) {
    return {
      error: true,
      message: `Aave V3 is not available on ${chain}. Aave is available on Base and Ethereum.`,
    };
  }

  let amountInUnits: bigint;
  try {
    amountInUnits = parseUnits(amount, 6); // USDC has 6 decimals
  } catch {
    return { error: true, message: `Invalid amount: "${amount}"` };
  }

  // Transaction 1: approve Aave Pool to spend USDC
  const approveData = encodeFunctionData({
    abi: ERC20_APPROVE_ABI,
    functionName: 'approve',
    args: [AAVE_POOL[chain], amountInUnits],
  });

  const approveTx = {
    to: USDC_ADDRESS[chain],
    data: approveData,
    value: '0',
    chainId: chain,
    description: `Allow Aave to use your USDC on ${chain}`,
    txType: 'approve',
  };

  // Transaction 2: supply to Aave Pool
  const supplyData = encodeFunctionData({
    abi: AAVE_SUPPLY_ABI,
    functionName: 'supply',
    args: [
      USDC_ADDRESS[chain],
      amountInUnits,
      walletAddress as `0x${string}`,
      0, // referralCode — always 0
    ],
  });

  const supplyTx = {
    to: AAVE_POOL[chain],
    data: supplyData,
    value: '0',
    chainId: chain,
    description: `Deposit ${amount} USDC into Aave V3 on ${chain}`,
    txType: 'supply',
  };

  return {
    unsignedTxs: [approveTx, supplyTx],
    summary: {
      protocol: 'Aave V3',
      chain,
      token: 'USDC',
      amount,
      action: 'supply',
      youReceive: `aUSDC — earns yield automatically in your wallet`,
      note: 'Two confirmations required: one to authorise, one to deposit.',
    },
  };
}

// ─── Mento swap builder ───────────────────────────────────────────

function buildMentoSwap(params: {
  amount: string;
  walletAddress: string;
}): { unsignedTxs: any[]; summary: any } {

  const { amount } = params;

  let amountInUnits: bigint;
  try {
    amountInUnits = parseUnits(amount, 6);
  } catch {
    amountInUnits = BigInt(0);
  }

  // Transaction 1: approve Mento Broker to spend USDC
  const approveData = encodeFunctionData({
    abi: ERC20_APPROVE_ABI,
    functionName: 'approve',
    args: [MENTO_BROKER, amountInUnits],
  });

  const approveTx = {
    to: USDC_ADDRESS['celo'],
    data: approveData,
    value: '0',
    chainId: 'celo',
    description: `Allow Mento to use your USDC on Celo`,
    txType: 'approve',
  };

  // Transaction 2: swap USDC → cUSD via Mento Broker
  // TODO Phase 5: Replace with real swapIn() call using the correct exchangeId.
  // The exchangeId for USDC→cUSD must be fetched from the Mento BiPoolManager
  // at runtime. For Phase 4, we return the approve transaction and a placeholder
  // for the swap. The swap will be completed in Phase 5 testnet work.
  const swapTx = {
    to: MENTO_BROKER,
    data: '0x', // placeholder — real swapIn calldata built in Phase 5
    value: '0',
    chainId: 'celo',
    description: `Swap ${amount} USDC to cUSD via Mento on Celo`,
    txType: 'mento_swap',
    isPlaceholder: true,
    placeholderNote: 'Mento swap transaction will be completed in Phase 5.',
  };

  return {
    unsignedTxs: [approveTx, swapTx],
    summary: {
      protocol: 'Mento',
      chain: 'celo',
      token: 'USDC',
      toToken: 'cUSD',
      amount,
      action: 'swap',
      youReceive: 'cUSD — Celo\'s native dollar stablecoin',
      note: 'Mento swap is in beta integration. Approve transaction is real. Swap completes in Phase 5.',
    },
  };
}

// ─── Main exported function ───────────────────────────────────────

export async function buildStakeTx(params: {
  chain: string;
  protocol: string;
  token: string;
  amount: string;
  walletAddress: string;
}): Promise<any> {

  const { chain, protocol, token, amount, walletAddress } = params;

  // Route to the correct protocol builder
  if (protocol === 'aave') {
    const result = buildAaveSupply({ chain, amount, walletAddress });
    if ('error' in result) {
      return { error: result.message };
    }
    return result;
  }

  if (protocol === 'mento') {
    if (chain !== 'celo') {
      return { error: `Mento is only available on Celo. You requested chain: ${chain}.` };
    }
    return buildMentoSwap({ amount, walletAddress });
  }

  // Unknown protocol — let the agent know
  return {
    error: `Protocol "${protocol}" is not supported. Available protocols: aave (Base, Ethereum), mento (Celo).`,
  };
}
```

---

## 🛠️ STEP 4 — UPDATE toolExecutor.ts FOR MULTIPLE UNSIGNED TXS

Read how toolExecutor currently handles the stake result:
```bash
cat backend/src/agent/toolExecutor.ts | grep -A 15 "stake"
```

`buildStakeTx` now returns `unsignedTxs` (array of 2 transactions), same pattern as
`buildBridgeTx` from Step 4.2. If you already updated the pattern in Step 4.2, confirm
the same pattern applies here. If not, update the stake case in toolExecutor:

```typescript
// In the 'build_stake_tx' case:
const result = await buildStakeTx(args);

if (result.error) {
  return { data: { error: result.error } };
}

const txs = result.unsignedTxs ?? [];

return {
  data: result.summary,
  unsignedTxs: txs,
};
```

---

## 🛠️ STEP 5 — TYPESCRIPT CHECK

```bash
npx tsc --noEmit
```

Fix all errors. Common issues:
- `walletAddress as \`0x${string}\`` — TypeScript needs the explicit hex string cast for viem
- `AAVE_SUPPLY_ABI as const` — the `const` assertion is required for viem's type inference
- `protocol` parameter might come in as mixed case from Gemini ("Aave" vs "aave") — normalise it: `protocol.toLowerCase()`

---

## 🛠️ STEP 6 — TEST WITH CURL

```bash
npm run dev
```

### Test 1 — Deposit USDC into Aave on Base
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Deposit 10 USDC into Aave on Base",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-stake-001"
  }'
```

**Expected:**
- `unsignedTxs` contains exactly 2 transactions
- `unsignedTxs[0].to` = USDC address on Base Sepolia (`0x036CbD53...`)
- `unsignedTxs[0].data` starts with `0x095ea7b3` (approve selector)
- `unsignedTxs[1].to` = Aave Pool on Base Sepolia (`0x07eA79F6...`)
- `unsignedTxs[1].data` starts with `0x617ba037` (supply function selector for Aave V3)
- Agent's plain-English response explains the deposit and mentions `aUSDC`

### Test 2 — Deposit USDC into Mento on Celo
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Stake 20 USDC on Celo using Mento",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-stake-002"
  }'
```

**Expected:**
- `unsignedTxs` contains 2 transactions
- `unsignedTxs[0]` is the approve tx on Celo
- `unsignedTxs[1]` has `isPlaceholder: true` and a note about Phase 5
- Agent's response explains the cUSD swap

### Test 3 — Unsupported protocol (graceful error)
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Stake 5 USDC on Compound",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-stake-003"
  }'
```

**Expected:** Agent explains that Compound is not supported, recommends Aave or Mento.

### Test 4 — Ask agent to find best rate and then deposit (combined flow)
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Find me the best yield for my USDC and deposit 50 USDC there",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-stake-004"
  }'
```

**Expected:** Agent calls `get_yield_rates` first, picks the highest APY protocol,
then calls `build_stake_tx` for that protocol. This tests the multi-tool reasoning
capability. The response should mention the chosen protocol's APY.

### Test 5 — Regression: all prior steps still work
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Move 5 USDC from Base to Celo",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-stake-005"
  }'
```
**Expected:** CCTP bridge still works. Steps 4.1–4.3 not broken.

---

## 🛠️ STEP 7 — VERIFY ABI SELECTORS

The Aave V3 `supply` function selector is `0x617ba037`.
From your curl response, verify `unsignedTxs[1].data` (the supply tx) starts with `0x617ba037`.

If it doesn't match, your ABI has a typo. The exact Aave V3 supply signature is:
`supply(address,uint256,address,uint16)` — the selector hash of this exact string is `0x617ba037`.

---

## 🛠️ STEP 8 — TYPESCRIPT CHECK (FINAL)

```bash
npx tsc --noEmit
```
Zero errors.

---

## 🛠️ STEP 9 — COMMIT

```bash
git add backend/src/services/stakeService.ts
git add backend/src/agent/toolExecutor.ts   # only if modified
git commit -m "feat: real Aave V3 supply + Mento approve transactions — Phase 4 Step 4.4"
git push
```

---

## 🛠️ STEP 10 — UPDATE PROGRESS.md

```
## 📍 CURRENT POSITION

PHASE:   4 — REAL SERVICE IMPLEMENTATIONS
STEP:    4.5 — WebSocket real-time transaction monitoring
STATUS:  IN PROGRESS

Dev 1: Step 4.4 complete. stakeService.ts builds real Aave V3 approve + supply
calldata. Mento approve is real; swap is Phase 5 placeholder with clear TODO.
Multi-tool test (find best yield then deposit) confirmed working.
Aave supply selector 0x617ba037 verified.

Next: Add WebSocket server and txMonitorService for real-time transaction status.
```

Mark complete:
```
- [x] Step 4.4: stakeService.ts replaced. Aave V3 approve+supply calldata real.
      Mento approve real, swap placeholder for Phase 5. Regression tests passed.
```

```bash
git add PROGRESS.md
git commit -m "progress: Phase 4 Step 4.4 complete — real stake transactions"
git push
```

---

## ✅ DONE WHEN — CHECKLIST

- [ ] `npx tsc --noEmit` returns zero errors
- [ ] Test 1: Aave deposit returns 2 txs, approve selector `0x095ea7b3`, supply selector `0x617ba037`
- [ ] Test 2: Mento deposit returns 2 txs — approve is real, swap has `isPlaceholder: true`
- [ ] Test 3: Unsupported protocol returns plain-English error, not a crash
- [ ] Test 4: Multi-tool flow (find yield then deposit) works in one conversation
- [ ] Test 5: CCTP bridge regression check passes
- [ ] PROGRESS.md updated and committed

---

## ⚠️ DO NOT DO THESE THINGS

1. **Do not rename `buildStakeTx`** — toolExecutor depends on this exact export name.
2. **Do not implement the full Mento swap** — the Mento exchange ID lookup is Phase 5 work. The TODO comment is intentional and correct.
3. **Do not add a third-party yield protocol** (Compound, Yearn, etc.) — Phase 4 only covers Aave and Mento as per PROGRESS.md.
4. **Do not use mainnet addresses** — testnet only in Phase 4.
5. **Do not remove the `isPlaceholder` flag** from the Mento swap tx — the frontend needs this to know not to submit it to the chain.

---

## 🆘 COMMON ERRORS AND FIXES

| Error | Cause | Fix |
|---|---|---|
| `supply` selector doesn't match `0x617ba037` | Parameter type typo in ABI | Exact signature: `supply(address,uint256,address,uint16)` — types must match exactly |
| `walletAddress` causes TypeScript error in `args` | Type mismatch — viem expects `0x${string}` | Cast: `walletAddress as \`0x${string}\`` |
| Agent calls `get_yield_rates` but not `build_stake_tx` in Test 4 | Gemini stopped after finding rates | Rephrase the message to be more explicit: "find the best yield rate and then deposit 50 USDC there for me" |
| `Protocol "Aave" not found` | Gemini sends "Aave" with capital A | Normalise in the function: `const normalizedProtocol = protocol.toLowerCase()` |

---

## 📚 REFERENCE LINKS

| Resource | URL |
|---|---|
| Aave V3 Pool supply() Docs | https://docs.aave.com/developers/core-contracts/pool#supply |
| Aave V3 Testnet Addresses | https://docs.aave.com/developers/deployed-contracts/v3-testnet-addresses |
| Mento Protocol Docs | https://docs.mento.org |
| Mento Broker Contract | https://docs.mento.org/mento/developers/smart-contracts |
| viem encodeFunctionData | https://viem.sh/docs/contract/encodeFunctionData |
| PROGRESS.md | /Automata-V2/PROGRESS.md |

---

*This session: Step 4.4 only. Next session: Step 4.5 — WebSocket real-time transaction monitoring.*
