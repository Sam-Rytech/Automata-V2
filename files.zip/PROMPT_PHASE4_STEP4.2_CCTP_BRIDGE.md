# 🤖 AUTOMATA — LLM SESSION PROMPT
## Phase 4 · Step 4.2 — Replace Circle CCTP Bridge Stub with Real CCTP V2
### For: Dev 1 (Backend Developer)
### Prerequisite: Step 4.1 must be complete — routeService.ts and swapService.ts use real @lifi/sdk

---

## 🔴 READ THIS ENTIRE PROMPT BEFORE WRITING A SINGLE LINE OF CODE

Do not install packages, open files, or run commands until you have finished reading
every section. The Circle CCTP V2 integration is the most architecturally complex
step in Phase 4. There are two transaction phases, an asynchronous attestation step,
and Stellar is handled differently from EVM chains. Understand the full picture first.

---

## 🧠 WHAT IS AUTOMATA — NEVER SKIP THIS

Automata is a cross-chain AI agent platform. The AI agent (Gemini Flash) receives
a user's plain-English intent, reasons over it, calls tools, and returns unsigned
transactions for the user to sign via Privy. The backend never holds funds, never
signs transactions, and never touches private keys.

The backend API is `POST /api/chat`. The agent calls tools. Tools call services.
Services build unsigned transactions. This step replaces the `bridgeService.ts` stub
with a real Circle CCTP V2 integration.

---

## 📍 WHERE YOU ARE

### ✅ Already complete
- Phase 0 — Accounts, credentials, infrastructure
- Phase 1 — Monorepo scaffold, Prisma, shared types
- Phase 2 — Full Gemini agent brain, 9 tools, conversation history
- Phase 3 (Backend) — All 9 services wired, `/api/chat` live and tested
- Phase 4 Step 4.1 — `routeService.ts` and `swapService.ts` use real `@lifi/sdk`

### 🔧 What you are doing in this session — Step 4.2
Replace `backend/src/services/bridgeService.ts` with a real Circle CCTP V2 integration
that builds genuine unsigned transactions for burning USDC on the source chain.

The function `buildBridgeTx` must remain exported with the same signature.
The `toolExecutor.ts` depends on this exact name — do not rename it.

### ⏳ After this session
- Step 4.3 — Real yield rates from Aave and Mento
- Step 4.4 — Real Aave/Mento stake transactions
- Step 4.5 — WebSocket real-time transaction monitoring

---

## 🗂️ FILE MAP — KNOW WHAT YOU ARE AND ARE NOT TOUCHING

```
backend/src/
├── agent/
│   ├── agent.ts          ← DO NOT TOUCH
│   ├── toolExecutor.ts   ← DO NOT TOUCH
│   ├── tools.ts          ← DO NOT TOUCH
│   └── prompts.ts        ← DO NOT TOUCH
├── services/
│   ├── routeService.ts   ← ✅ Done in Step 4.1 — DO NOT TOUCH
│   ├── swapService.ts    ← ✅ Done in Step 4.1 — DO NOT TOUCH
│   ├── bridgeService.ts  ← 🎯 YOU ARE REPLACING THIS TODAY
│   ├── balanceService.ts ← Real already — DO NOT TOUCH
│   ├── yieldService.ts   ← Leave for Step 4.3
│   ├── stakeService.ts   ← Leave for Step 4.4
│   ├── transferService.ts← Real already — DO NOT TOUCH
│   ├── feeService.ts     ← Leave as stub
│   └── resolverService.ts← Leave as stub
├── adapters/
│   ├── evm.ts            ← DO NOT TOUCH (Dev 2 owns)
│   └── stellar.ts        ← DO NOT TOUCH (Dev 2 owns)
└── utils/
    └── rpc.ts            ← DO NOT TOUCH (Dev 2 owns)
```

---

## 🔑 STEP 0 — VERIFY YOUR ENVIRONMENT

Run all commands from the `backend/` folder.

### 0a. Confirm the backend starts cleanly
```bash
npm run dev
```
In a second terminal:
```bash
curl http://localhost:3001/health
```
Expected: `{"status":"ok","timestamp":"..."}`. If not — fix it before continuing.

### 0b. Confirm TypeScript is clean
```bash
npx tsc --noEmit
```
Expected: zero output, zero errors. Do not proceed if there are errors.

### 0c. Confirm Step 4.1 still works
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What is the best route to swap 10 USDC from Base to cUSD on Celo?",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-verify-001"
  }'
```
Expected: agent responds with a real LI.FI route. If this is broken, fix it before continuing.

### 0d. Check your .env for the Circle API key
```bash
cat .env | grep CIRCLE
```
You need `CIRCLE_API_KEY=` to be set. This is used for testnet only in Phase 4.

**If you don't have a Circle API key:**
1. Go to https://console.circle.com
2. Sign up for a free developer account
3. Go to API Keys → Create API key
4. Select "Testnet" environment
5. Copy the key into `backend/.env`: `CIRCLE_API_KEY=your_key_here`

**Note:** The CCTP burn-and-attest flow does NOT require a Circle API key for the
on-chain transactions themselves — the key is only needed if you use Circle's
attestation API to fetch the mint message. The unsigned burn transaction is built
entirely from ABI calls, which requires only your RPC URL.

### 0e. Confirm you have testnet RPC URLs
```bash
cat .env | grep RPC
```
You need at minimum:
```
BASE_RPC_URL=   ← must point to Base Sepolia testnet
CELO_RPC_URL=   ← must point to Celo Alfajores testnet
ETH_RPC_URL=    ← can point to Ethereum Sepolia or mainnet for now
```

**If your RPC URLs currently point to mainnet** (e.g. `https://mainnet.base.org`),
you must switch them to testnet for Phase 4. Update your `.env`:
```
BASE_RPC_URL=https://sepolia.base.org
CELO_RPC_URL=https://alfajores-forno.celo-testnet.org
ETH_RPC_URL=https://rpc.sepolia.org
STELLAR_HORIZON_URL=https://horizon-testnet.stellar.org
```

**Why testnet?** PROGRESS.md Phase 4 goal explicitly states: "Everything on testnet first,
then mainnet." You are not spending real money in Phase 4.

---

## 🧠 STEP 1 — UNDERSTAND CIRCLE CCTP V2 BEFORE WRITING CODE

Read this section fully. It explains the entire flow you are implementing.

### What is CCTP?

Circle CCTP (Cross-Chain Transfer Protocol) V2 is a burn-and-mint bridge specifically
for USDC. It is the only correct way to move USDC across chains without wrapping.
When a user bridges 50 USDC from Base to Celo:
1. Their 50 USDC on Base is burned (destroyed) by the CCTP contract
2. Circle's attestation service detects the burn event
3. A new 50 USDC is minted on Celo — exact same amount, no slippage, no fee to Circle

### The two-phase transaction flow

Circle CCTP requires TWO separate on-chain transactions by the user:

**Phase A — Burn (on source chain):**
The user submits two transactions in sequence:
1. `approve()` — the user approves the USDC contract to allow the CCTP TokenMessenger to spend their USDC
2. `depositForBurn()` — the CCTP TokenMessenger burns the USDC

Both are EVM transactions that happen on the source chain (e.g. Base Sepolia).

**Phase B — Mint (on destination chain):**
After Circle attests the burn (~30–90 seconds), the user submits:
3. `receiveMessage()` — the CCTP MessageTransmitter mints the USDC on the destination chain

**What you build in this session:**
You are building Phase A only (approve + burn transactions).
Phase B (mint) requires the attestation message, which isn't available until after
the burn is confirmed on-chain. The frontend will handle fetching the attestation
and building Phase B in Phase 5. For now, you return the approve and burn transactions.

### The contracts you interact with

**On every EVM chain (testnet addresses):**

TokenMessenger contract — handles the burn:
```
Base Sepolia:     0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5
Celo Alfajores:   0x877B0900F3c46d91CDBDB76E4a0C7B67B1640E13
Ethereum Sepolia: 0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5
```

USDC contract — the token being burned:
```
Base Sepolia:     0x036CbD53842c5426634e7929541eC2318f3dCF7e
Celo Alfajores:   0x2F25deB3848C207fc8E0c34035B3Ba7fC157602B
Ethereum Sepolia: 0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238
```

MessageTransmitter contract — handles the mint (Phase B, not today):
```
Base Sepolia:     0x7865fAfC2db2093669d92c0197e5d6f4D14BF38
Celo Alfajores:   0x7865fAfC2db2093669d92c0197e5d6f4D14BF38
```

### CCTP domain IDs (used in depositForBurn)
Circle uses integer domain IDs, not chain names:
```
Ethereum = 0
Base     = 6
Celo     = 7
Stellar  = 4  (not EVM — handled separately)
```

### The depositForBurn function signature
```solidity
function depositForBurn(
    uint256 amount,           // USDC amount in smallest unit (6 decimals)
    uint32 destinationDomain, // CCTP domain ID of destination chain
    bytes32 mintRecipient,    // destination address padded to 32 bytes
    address burnToken         // USDC contract address on source chain
) external returns (uint64 nonce);
```

Note: `mintRecipient` is the destination wallet address zero-padded to 32 bytes.
Convert from EVM address: `0x000...000 + address` (pad left with zeros to 66 hex chars total).

### Stellar USDC bridge — important difference
Bridging USDC to Stellar follows a different path. Circle supports Stellar natively
in CCTP V2, but the mint recipient format is different (Stellar uses 32-byte keys
in a specific encoding). For this step, implement EVM-to-EVM bridging only.
Return an error message if `toChain === 'stellar'` instructing the agent that
Stellar bridging is handled differently and will be available in a future update.
This keeps the scope manageable without breaking the user experience.

---

## 🛠️ STEP 2 — READ THE CURRENT STUB FILE

Before writing anything, read the existing file:
```bash
cat backend/src/services/bridgeService.ts
```

Note:
- The exported function name (must stay exactly `buildBridgeTx`)
- The parameter shape it accepts
- The return value shape it currently produces

Also read the toolExecutor to confirm how it calls bridgeService:
```bash
cat backend/src/agent/toolExecutor.ts | grep -A 10 "bridge"
```

Confirm the return shape the toolExecutor expects. Your new implementation must
return data in that exact shape.

---

## 🛠️ STEP 3 — INSTALL REQUIRED PACKAGES

You will use `viem` to encode the calldata for CCTP. It should already be installed,
but confirm:
```bash
cat package.json | grep viem
```

No additional packages are needed. CCTP integration is done by encoding ABI calls
directly using viem's `encodeFunctionData`. No Circle SDK is required for Phase 4.

---

## 🛠️ STEP 4 — WRITE THE NEW bridgeService.ts

Create the new implementation. Full structure to implement:

```typescript
// backend/src/services/bridgeService.ts

import { encodeFunctionData, parseUnits, pad } from 'viem';

// ─── CCTP Contract Addresses (Testnet) ───────────────────────────

const TOKEN_MESSENGER: Record<string, `0x${string}`> = {
  base:     '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
  celo:     '0x877B0900F3c46d91CDBDB76E4a0C7B67B1640E13',
  ethereum: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
};

const USDC_ADDRESS: Record<string, `0x${string}`> = {
  base:     '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
  celo:     '0x2F25deB3848C207fc8E0c34035B3Ba7fC157602B',
  ethereum: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
};

// CCTP domain IDs
const CCTP_DOMAIN: Record<string, number> = {
  ethereum: 0,
  base:     6,
  celo:     7,
};

// ─── ABI Fragments ───────────────────────────────────────────────

// ERC-20 approve ABI
const ERC20_APPROVE_ABI = [
  {
    name: 'approve',
    type: 'function',
    inputs: [
      { name: 'spender', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
] as const;

// CCTP depositForBurn ABI
const DEPOSIT_FOR_BURN_ABI = [
  {
    name: 'depositForBurn',
    type: 'function',
    inputs: [
      { name: 'amount', type: 'uint256' },
      { name: 'destinationDomain', type: 'uint32' },
      { name: 'mintRecipient', type: 'bytes32' },
      { name: 'burnToken', type: 'address' },
    ],
    outputs: [{ name: 'nonce', type: 'uint64' }],
  },
] as const;

// ─── Helper: convert EVM address to bytes32 mint recipient ───────

function addressToBytes32(address: string): `0x${string}` {
  // Remove 0x prefix, pad to 64 hex chars (32 bytes), add 0x back
  const clean = address.toLowerCase().replace('0x', '');
  return `0x${clean.padStart(64, '0')}`;
}

// ─── Main exported function ───────────────────────────────────────

export async function buildBridgeTx(params: {
  fromChain: string;
  toChain: string;
  amount: string;
  walletAddress: string;
  recipientAddress: string;
}): Promise<any> {

  const { fromChain, toChain, amount, walletAddress, recipientAddress } = params;

  // ── Validation ────────────────────────────────────────────────

  if (toChain === 'stellar') {
    return {
      error: true,
      message: 'Bridging to Stellar requires a special flow that is not yet available. ' +
               'You can bridge USDC to Base or Celo today.',
    };
  }

  if (!TOKEN_MESSENGER[fromChain]) {
    return {
      error: true,
      message: `Bridging from ${fromChain} is not supported. Supported chains: base, celo, ethereum.`,
    };
  }

  if (!CCTP_DOMAIN[toChain]) {
    return {
      error: true,
      message: `Bridging to ${toChain} is not supported. Supported destination chains: base, celo, ethereum.`,
    };
  }

  if (fromChain === toChain) {
    return {
      error: true,
      message: `Source and destination chains are the same (${fromChain}). Choose different chains.`,
    };
  }

  // ── Convert amount to USDC smallest unit (6 decimals) ─────────
  let amountInUnits: bigint;
  try {
    amountInUnits = parseUnits(amount, 6);
  } catch {
    return {
      error: true,
      message: `Invalid amount: "${amount}". Please provide a number like "10" or "50.5".`,
    };
  }

  // ── Build Transaction 1: approve ─────────────────────────────
  // The user must approve the TokenMessenger to spend their USDC before burning.
  const approveData = encodeFunctionData({
    abi: ERC20_APPROVE_ABI,
    functionName: 'approve',
    args: [TOKEN_MESSENGER[fromChain], amountInUnits],
  });

  const approveTx = {
    to: USDC_ADDRESS[fromChain],
    data: approveData,
    value: '0',
    chainId: fromChain,
    description: `Allow Automata to move ${amount} USDC on ${fromChain}`,
    txType: 'approve',
  };

  // ── Build Transaction 2: depositForBurn ───────────────────────
  const mintRecipient = addressToBytes32(recipientAddress);
  const destinationDomain = CCTP_DOMAIN[toChain];

  const burnData = encodeFunctionData({
    abi: DEPOSIT_FOR_BURN_ABI,
    functionName: 'depositForBurn',
    args: [
      amountInUnits,
      destinationDomain,
      mintRecipient as `0x${string}`,
      USDC_ADDRESS[fromChain],
    ],
  });

  const burnTx = {
    to: TOKEN_MESSENGER[fromChain],
    data: burnData,
    value: '0',
    chainId: fromChain,
    description: `Move ${amount} USDC from ${fromChain} to ${toChain}`,
    txType: 'burn',
  };

  // ── Return both transactions ───────────────────────────────────
  // The frontend (Privy) will send them in sequence.
  // tx[0] = approve, tx[1] = burn.
  // After the burn confirms, the frontend polls for the Circle attestation
  // and builds the mint transaction on the destination chain (Phase B — Phase 5).

  return {
    unsignedTxs: [approveTx, burnTx],
    summary: {
      fromChain,
      toChain,
      amount,
      fromToken: 'USDC',
      toToken: 'USDC',
      estimatedTimeSeconds: 90,
      estimatedFeeUSD: '< $0.01',  // CCTP has no bridge fee — user pays only gas
      note: 'Two confirmations required: one to authorise, one to send. ' +
            'USDC will arrive on ' + toChain + ' within ~90 seconds.',
    },
    // CCTP mint info — frontend needs this to complete Phase B
    cctpMintInfo: {
      destinationChain: toChain,
      recipientAddress,
      destinationDomain,
      // mintRecipient and burnToken stored for the frontend to build the mint tx
    },
  };
}
```

---

## 🛠️ STEP 5 — UPDATE toolExecutor.ts TO HANDLE MULTIPLE UNSIGNED TXS

Read the current toolExecutor:
```bash
cat backend/src/agent/toolExecutor.ts
```

The current toolExecutor likely handles a single `unsignedTx` per tool call.
`buildBridgeTx` now returns `unsignedTxs` (plural — an array of two transactions).

Update the `build_bridge_tx` case in toolExecutor to handle this correctly.
The pattern should be: if the result has `unsignedTxs` (array), spread them all into
the response. If it has `unsignedTx` (single), wrap it. Example:

```typescript
// In toolExecutor.ts, in the switch/if case for 'build_bridge_tx':
const result = await buildBridgeTx(args);

if (result.error) {
  return { data: { error: result.message } };
}

// Handle multiple transactions (CCTP returns approve + burn)
const txs = result.unsignedTxs ?? (result.unsignedTx ? [result.unsignedTx] : []);

return {
  data: result.summary,
  unsignedTxs: txs,   // note: plural — return array
};
```

Also check `agent.ts` — verify it is built to collect multiple `unsignedTxs` per tool call:
```bash
cat backend/src/agent/agent.ts | grep -A 5 "unsignedTx"
```

If it only handles `toolResult.unsignedTx` (singular), update it to also handle
`toolResult.unsignedTxs` (array):
```typescript
if (toolResult.unsignedTxs && Array.isArray(toolResult.unsignedTxs)) {
  unsignedTxs.push(...toolResult.unsignedTxs);
} else if (toolResult.unsignedTx) {
  unsignedTxs.push(toolResult.unsignedTx);
}
```

---

## 🛠️ STEP 6 — VERIFY WITH TYPESCRIPT

```bash
npx tsc --noEmit
```

Fix every error. Common issues:
- `pad` may not be exported from the version of viem you have — use `addressToBytes32` helper above instead
- `bytes32` type — use the string literal type `\`0x${string}\`` in TypeScript
- If `parseUnits` throws on invalid input, the try/catch handles it

---

## 🛠️ STEP 7 — TEST WITH CURL

Start the backend:
```bash
npm run dev
```

### Test 1 — Basic bridge request
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Move 5 USDC from Base to Celo",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-cctp-001"
  }'
```

**Expected:** Agent calls `build_bridge_tx`, returns a response with `unsignedTxs` containing
exactly two transactions — approve first, burn second. The `to` address of the burn tx must
match the Base Sepolia TokenMessenger address (`0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5`).

Verify from the JSON response:
```
unsignedTxs[0].to   === USDC address on Base (approve tx)
unsignedTxs[0].data  starts with 0x095ea7b3 (approve function selector)
unsignedTxs[1].to   === TokenMessenger address on Base (burn tx)
unsignedTxs[1].data  starts with 0x6fd3504e (depositForBurn function selector)
```

### Test 2 — Stellar bridge (must return graceful error)
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Bridge 10 USDC from Base to Stellar",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-cctp-002"
  }'
```

**Expected:** Agent responds with a plain-English message explaining that Stellar
bridging is not available yet and suggesting Base or Celo instead. No crash, no
raw error, no stack trace in the response.

### Test 3 — Same-chain bridge (must return graceful error)
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Bridge 10 USDC from Base to Base",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-cctp-003"
  }'
```

**Expected:** Agent responds explaining source and destination are the same chain.

### Test 4 — Step 4.1 still works (regression check)
```bash
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Swap 10 USDC to cUSD on Celo",
    "walletAddress": "0x0000000000000000000000000000000000000001",
    "geminiApiKey": "YOUR_GEMINI_KEY_HERE",
    "sessionId": "test-cctp-004"
  }'
```

**Expected:** Agent still calls `get_route` via LI.FI, not the bridge service.
Step 4.1 must not be broken.

---

## 🛠️ STEP 8 — VERIFY ABI FUNCTION SELECTORS

This optional but strongly recommended check confirms your calldata is correct.

The function selector is the first 4 bytes of the encoded calldata (after `0x`).
Known correct selectors:
- `approve(address,uint256)` → `0x095ea7b3`
- `depositForBurn(uint256,uint32,bytes32,address)` → `0x6fd3504e`

From your curl response, extract `unsignedTxs[0].data` and `unsignedTxs[1].data`.
Check that the first 10 characters (including `0x`) match these selectors.

If they don't match, your ABI definition has a typo — check parameter order and types.

---

## 🛠️ STEP 9 — TYPESCRIPT CHECK (FINAL)

```bash
npx tsc --noEmit
```
Zero errors required before committing.

---

## 🛠️ STEP 10 — COMMIT

```bash
git add backend/src/services/bridgeService.ts
git add backend/src/agent/toolExecutor.ts
git add backend/src/agent/agent.ts   # only if you modified it
git commit -m "feat: Circle CCTP V2 real bridge transactions — Phase 4 Step 4.2"
git push
```

---

## 🛠️ STEP 11 — UPDATE PROGRESS.md

```
## 📍 CURRENT POSITION

PHASE:   4 — REAL SERVICE IMPLEMENTATIONS
STEP:    4.3 — Real yield rates from Aave and Mento
STATUS:  IN PROGRESS

Dev 1: Step 4.2 complete. bridgeService.ts replaced with real Circle CCTP V2.
Approve + burn transactions build correctly for Base↔Celo and Base↔Ethereum.
Stellar bridging returns graceful error (will be implemented in Phase 5 testnet work).
Curl tests verified: approve selector 0x095ea7b3 confirmed, depositForBurn selector
0x6fd3504e confirmed.

Next: Replace yieldService.ts stub with real Aave V3 and Mento on-chain reads.
```

Mark complete:
```
- [x] Step 4.2: bridgeService.ts replaced with real Circle CCTP V2.
      Approve + depositForBurn calldata verified. Error cases handled gracefully.
```

Commit the progress update:
```bash
git add PROGRESS.md
git commit -m "progress: Phase 4 Step 4.2 complete — Circle CCTP V2 bridge integrated"
git push
```

---

## ✅ DONE WHEN — CHECKLIST

This step is complete ONLY when all of the following are true:

- [ ] `npx tsc --noEmit` returns zero errors
- [ ] Test 1: Bridge Base → Celo returns `unsignedTxs` array with exactly 2 transactions
- [ ] Test 1: `unsignedTxs[0].to` matches USDC address on Base Sepolia
- [ ] Test 1: `unsignedTxs[1].to` matches TokenMessenger address on Base Sepolia
- [ ] Test 1: `unsignedTxs[0].data` starts with `0x095ea7b3` (approve selector)
- [ ] Test 1: `unsignedTxs[1].data` starts with `0x6fd3504e` (depositForBurn selector)
- [ ] Test 2: Stellar bridge returns graceful error message, not a crash
- [ ] Test 3: Same-chain bridge returns graceful error message
- [ ] Test 4: Step 4.1 (LI.FI swap) still works — not broken by this change
- [ ] PROGRESS.md updated and committed

---

## ⚠️ DO NOT DO THESE THINGS

1. **Do not rename `buildBridgeTx`** — `toolExecutor.ts` imports this by exact name.
2. **Do not use Circle's SDK package** — the calldata can be built cleanly with viem's
   `encodeFunctionData` and requires no additional dependencies.
3. **Do not implement the mint (Phase B) transaction** — that requires an attestation
   message that only exists after the burn is confirmed on-chain. It is handled in Phase 5.
4. **Do not implement Stellar bridging yet** — return a graceful error and move on.
5. **Do not switch RPC URLs back to mainnet** — Phase 4 is testnet only.
6. **Do not hardcode walletAddress** — always use the `walletAddress` / `recipientAddress`
   params passed into the function.

---

## 🆘 COMMON ERRORS AND FIXES

| Error | Cause | Fix |
|---|---|---|
| `encodeFunctionData` type error on `bytes32` | TypeScript strict mode on hex string type | Cast explicitly: `mintRecipient as \`0x${string}\`` |
| `parseUnits` not found | Wrong import | `import { parseUnits } from 'viem'` |
| `depositForBurn` selector is wrong | Typo in ABI parameter types | Compare against verified selector `0x6fd3504e` — recheck param order: `uint256, uint32, bytes32, address` |
| Agent doesn't call `build_bridge_tx` | Gemini routed to LI.FI instead | This is correct for token swaps. Test with an explicit "bridge USDC" request (CCTP is for USDC-specific bridging, LI.FI is for other tokens) |
| Two unsigned txs not appearing in response | `toolExecutor.ts` not updated for plural `unsignedTxs` | Re-read Step 5 above and update the tool executor accordingly |
| `addressToBytes32` produces wrong length | Off-by-one in padding | The output must always be `0x` + 64 hex characters = 66 characters total |

---

## 📚 REFERENCE LINKS

| Resource | URL |
|---|---|
| Circle CCTP V2 Docs | https://developers.circle.com/cctp |
| CCTP Contract Addresses | https://developers.circle.com/stablecoins/docs/cctp-protocol-contract |
| Base Sepolia Explorer | https://sepolia.basescan.org |
| Celo Alfajores Explorer | https://alfajores.celoscan.io |
| Base Sepolia USDC Faucet | https://faucet.circle.com |
| viem encodeFunctionData | https://viem.sh/docs/contract/encodeFunctionData |
| PROGRESS.md (source of truth) | /Automata-V2/PROGRESS.md |

---

*This session: Step 4.2 only. Next session: Step 4.3 — Real yield rates from Aave and Mento.*
